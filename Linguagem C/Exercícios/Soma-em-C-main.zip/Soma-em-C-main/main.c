/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main(void)
{
        int a, b, c;
        printf("a: ");
       scanf("%d", &a);
        printf("b: ");
      scanf("%d", &b);
     c = a + b;
       printf("a + b = %d\n", c);
     return 0;
}


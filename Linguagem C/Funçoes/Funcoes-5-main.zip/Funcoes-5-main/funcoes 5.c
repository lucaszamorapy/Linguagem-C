/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int verifica(int c){
 
    if (c > 0){
        printf("O valor digitado é positivo\n");
    }
    else{
        printf("O valor digitado é negativo\n");
    }
}
int soma(int a, int b,int c){
    c=a+b;
}
main(){
    int a,b,c;
    
    printf("A:\n");
    scanf("%d",&a);
    printf("B:\n");
    scanf("%d",&b);
    int soma(a,b,c);
    
}

